package com.mygdx.game.desktop;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.badlogic.gdx.tools.texturepacker.TexturePacker;
import com.mygdx.game.Play;
import com.mygdx.items.Items_shop;

public class DesktopLauncher {
	public static void main (String[] arg) {
LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		
		config.title = "Game";
		config.width = 600;
		config.height = 400;
		config.vSyncEnabled = false;
		config.foregroundFPS = 200;
		
		//TexturePacker.process("C:\\Users\\ADMIN\\Desktop\\OOP\\game\\core\\assets\\unpacked", "C:\\Users\\ADMIN\\Desktop\\OOP\\game\\core\\assets\\packed", "textures");
		new LwjglApplication(new Play(), config);

	}
}
