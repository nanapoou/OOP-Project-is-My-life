package com.mygdx.state;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Animation.PlayMode;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.mygdx.game.Play;
import com.mygdx.game.Settings;
import com.mygdx.managers.GameKeys;
import com.mygdx.model.Actor;
import com.mygdx.model.Camera;
import com.mygdx.model.TERRAIN;
import com.mygdx.model.TileMap;
import com.mygdx.util.AnimationSet;
import com.badlogic.gdx.Input.Keys;
import com.mygdx.items.Items_shop;

public class PlayState extends State{
	
	private GameKeys keys;
	
//	private Items_shop items;
	
	private SpriteBatch batch;
	private Texture red;
    private Texture laboratory, labdoor, house1, house, hotel, shop1, storage, storagedoor;
    private Texture dirt, dirt_north, dirt_path, dirt_west, dirt_east,dirt_northwest, dirt_northeast, dirt_southwest, dirt_southeast;
	private Texture grass1, grass2, flower_left, flower_middle, dir2, rug, sign, tree, largetree;
	private Texture menu1, menu2, menu3;
	private BitmapFont font;
	
	private Camera camera;
	private Actor player;
	private TileMap map;
	private float playerX,playerY, dirX1,dirY1,dirX2,dirY2,dirX3,dirY3,floorX1,floorY1,floorX2,floorY2,floorX3,floorY3;
	private int money = 1000;
	

	public PlayState(Play p) {
		super(p);
		
		batch = new SpriteBatch();
		red = new Texture("unpacked/brendan_stand_south.png"); // ����Ф�
		// Tiles Input //
		grass1 = new Texture("grass1.png");
		grass2 = new Texture("grass2.png");
		dir2 = new Texture("brown_path.png");
		dirt = new Texture("dirt.png");
		dirt_northwest = new Texture("dirt_northwest.png");
		dirt_northeast = new Texture("dirt_northeast.png");
		dirt_southwest = new Texture("dirt_southwest.png");
		dirt_southeast = new Texture("dirt_southeast.png");	
		dirt_west = new Texture("dirt_west.png");
		dirt_east = new Texture("dirt_east.png");
		dirt_north = new Texture("dirt_north.png");
		dirt_path = new Texture("dirt_path.png");
		// Building //
		shop1 = new Texture("shop_1.png");
		house1 = new Texture("house_1.png");
		hotel = new Texture("hotel_1.png");
		laboratory = new Texture("Laboratory.png");
		labdoor = new Texture("labDoor.png");
		storage = new Texture("storage.png");
		storagedoor = new Texture("storagedoor.png");
		// Props //
		flower_left = new Texture("flowers.png");
		flower_middle = new Texture("flowers_1.png");
		rug = new Texture("rug.png");
		tree = new Texture("tree_1.png");
		largetree = new Texture("large_tree.png");
		sign = new Texture("sign.png");
		menu1 = new Texture("menu1.png");
		menu2 = new Texture("menu2.png");
		menu3 = new Texture("menu3.png");
		
		TextureAtlas atlas = p.getAssetManager().get("packed/textures.atlas", TextureAtlas.class);
		
		AnimationSet animations = new AnimationSet(
				new Animation(0.3f/2f, atlas.findRegions("brendan_walk_north"), PlayMode.LOOP_PINGPONG),
				new Animation(0.3f/2f, atlas.findRegions("brendan_walk_south"), PlayMode.LOOP_PINGPONG),
				new Animation(0.3f/2f, atlas.findRegions("brendan_walk_east"), PlayMode.LOOP_PINGPONG),
				new Animation(0.3f/2f, atlas.findRegions("brendan_walk_west"), PlayMode.LOOP_PINGPONG),
				atlas.findRegion("brendan_stand_north"),
				atlas.findRegion("brendan_stand_south"),
				atlas.findRegion("brendan_stand_east"),
				atlas.findRegion("brendan_stand_west")
				);
		
		map = new TileMap(50, 50); // ��Ҵ �ͧ MAP
		player = new Actor(map, 10, 0, animations); // �ش������Ф��Դ
		camera = new Camera();
		
		keys = new GameKeys(player);
		font = new BitmapFont();
		font.setColor(1f, 0f, 0f, 1f);
	}

	@Override
	public void show() {
		Gdx.input.setInputProcessor(keys);
	}

	@Override
	public void render(float delta) {
		
		
		keys.update(delta);
		
		player.update(delta);
		
		camera.update(player.getWorldX()+0.5f, player.getWorldY()+0.5f);
		
		batch.begin();
		
		float worldStartX = Gdx.graphics.getWidth()/2 - camera.getCameraX()*Settings.SCALED_TILE_SIZE;
		float worldStartY = Gdx.graphics.getHeight()/2 - camera.getCameraY()*Settings.SCALED_TILE_SIZE;
		
		for (int x = 0; x < map.getWidth(); x++) {
			for (int y = 0; y < map.getHeight(); y++) {
				Texture r;
				if (map.getTile(x, y).getTerrain() == TERRAIN.GRASS_1) {
					r = grass1;
				} else {
					r = grass2;
				}
				batch.draw(r,
						worldStartX + x * Settings.SCALED_TILE_SIZE,
						worldStartY + y * Settings.SCALED_TILE_SIZE,
						Settings.SCALED_TILE_SIZE, 
						Settings.SCALED_TILE_SIZE);
			}
		}
		
//=========================================== model ===================================================================		
		
		// ------------------- Drawing House (Behind Objects) ----------------------- //
		batch.draw(dirt_northwest, // Secret Path Tree
				worldStartX + 16 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(tree, // Tree in Playground Behind Hotel
				worldStartX + 16 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 2);
		batch.draw(tree, // Tree in Playground Behind Hotel
				worldStartX + 16 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 2);
		batch.draw(labdoor, 
				worldStartX + 16 * Settings.SCALED_TILE_SIZE,
				worldStartY + 16 * Settings.SCALED_TILE_SIZE,
				33, //Width
				44); //Height
		batch.draw(laboratory, 
				worldStartX + 12 * Settings.SCALED_TILE_SIZE,
				worldStartY + 16 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 7, //Width
				Settings.SCALED_TILE_SIZE * 4); //Height
		// Laboratory Dirt //
		batch.draw(dirt_west, 
				worldStartX + 2 * Settings.SCALED_TILE_SIZE,
				worldStartY + 14 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1);
		
		// ------------------Start path----------------------- //
					// Spawn part //
		batch.draw(dirt_southwest, // Spawn part
				worldStartX + 9 * Settings.SCALED_TILE_SIZE,
				worldStartY + 0 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_southeast, // Spawn part
				worldStartX + 10 * Settings.SCALED_TILE_SIZE,
				worldStartY + 0 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		// Straight up Path from spawn part //
		for (int i=1; i < 18; i++) { 
		batch.draw(dirt_west, 
			worldStartX + 9 * Settings.SCALED_TILE_SIZE,
			worldStartY + i * Settings.SCALED_TILE_SIZE,
			Settings.SCALED_TILE_SIZE * 1,
			Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(dirt_east, 
			worldStartX + 10 * Settings.SCALED_TILE_SIZE,
			worldStartY + i * Settings.SCALED_TILE_SIZE,
			Settings.SCALED_TILE_SIZE * 1,
			Settings.SCALED_TILE_SIZE * 1);
		}
		// Intersection above the spawn point & Intersection to the First shop//
		for (int i = 2; i < 29 ; i++) {
		batch.draw(dirt, 
			worldStartX + i * Settings.SCALED_TILE_SIZE,
			worldStartY + 4 * Settings.SCALED_TILE_SIZE,
			Settings.SCALED_TILE_SIZE * 1,
			Settings.SCALED_TILE_SIZE * 1);
		}
		batch.draw(dirt_west, 
			worldStartX + 2 * Settings.SCALED_TILE_SIZE,
			worldStartY + 4 * Settings.SCALED_TILE_SIZE,
			Settings.SCALED_TILE_SIZE * 1,
			Settings.SCALED_TILE_SIZE * 1);
		// Intersection to the Second shop //
		for (int i = 3; i < 10 ; i++) {
			batch.draw(dirt, 
			worldStartX + i * Settings.SCALED_TILE_SIZE,
			worldStartY + 9 * Settings.SCALED_TILE_SIZE,
			Settings.SCALED_TILE_SIZE * 1,
			Settings.SCALED_TILE_SIZE * 1);
		}
		batch.draw(dirt_west, 
				worldStartX + 2 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		// Intersection above the second shop & Intersection to the Third shop //
		for (int i = 3; i < 29 ; i++) {
			batch.draw(dirt, 
				worldStartX + i * Settings.SCALED_TILE_SIZE,
				worldStartY + 14 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1); 
			}
		// End of the Road Dirt //
		batch.draw(dirt_northwest, 
				worldStartX + 9 * Settings.SCALED_TILE_SIZE,
				worldStartY + 18 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_northeast, 
				worldStartX + 10 * Settings.SCALED_TILE_SIZE,
				worldStartY + 18 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1); 
		// Side straight long path near house & tree //
		for (int i = 14; i > 3 ; i--) {
			batch.draw(dirt, 
				worldStartX + 29 * Settings.SCALED_TILE_SIZE,
				worldStartY +  i * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1); 
		}
		
		// ------------------------- Playground ---------------------- //
		batch.draw(dirt_southwest, 
				worldStartX + 12 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_northwest, 
				worldStartX + 12 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt, 
				worldStartX + 13 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt, 
				worldStartX + 13 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_southeast, 
				worldStartX + 14 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_northeast, 
				worldStartX + 14 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_path, 
				worldStartX + 11 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_north, 
				worldStartX + 16 * Settings.SCALED_TILE_SIZE,
				worldStartY + 15 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		// ------------- Secret Path ----------- //
		batch.draw(dirt_northeast,
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_east,
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_southwest,
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_northeast,
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(dirt_southwest,
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + 8 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
				
		// -------------------- Plant Flowers ----------------------//
				
		batch.draw(flower_middle, // Flowers at the spawn point
				worldStartX + 8 * Settings.SCALED_TILE_SIZE,
				worldStartY + 3 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers at the spawn point
				worldStartX + 7 * Settings.SCALED_TILE_SIZE,
				worldStartY + 3 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers in Playground
				worldStartX + 15 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers in Playground
				worldStartX + 15 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers near house beside hotel
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 6 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers near house beside hotel
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1); 
		batch.draw(flower_middle, // Flowers near house beside hotel
				worldStartX + 28 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1);
		batch.draw(flower_middle, // Flowers near house beside hotel
				worldStartX + 28 * Settings.SCALED_TILE_SIZE,
				worldStartY + 6 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 1); 

		// -------------------- Player -------------------------//
		batch.draw(player.getSprite(), 
				worldStartX + player.getWorldX() * Settings.SCALED_TILE_SIZE, 
				worldStartY + player.getWorldY() * Settings.SCALED_TILE_SIZE, 
				Settings.SCALED_TILE_SIZE, 
				Settings.SCALED_TILE_SIZE);
		// -------------------- Plant Tree ----------------------//
		batch.draw(tree, // Side hotel tree
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 8 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 2); 
		batch.draw(tree, // Side hotel tree
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 7 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 2); 
		for (int i = 18 ; i > 14 ; i--) { // Covering laboratory tree from side
			batch.draw(tree, 
				worldStartX + 11 * Settings.SCALED_TILE_SIZE,
				worldStartY + i * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, //Width
				Settings.SCALED_TILE_SIZE * 2); //Height
		}
		for (int i = 18 ; i > 14 ; i--) { // Covering laboratory tree from side
			batch.draw(tree, 
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + i * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 2);
		}
		for (int i = 12 ; i < 16 ; i++) { // Covering laboratory tree from below
			batch.draw(tree, 
				worldStartX + i * Settings.SCALED_TILE_SIZE,
				worldStartY + 15 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 2); 
		}
		batch.draw(tree, // Covering laboratory tree from below
				worldStartX + 17 * Settings.SCALED_TILE_SIZE,
				worldStartY + 15 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, 
				Settings.SCALED_TILE_SIZE * 2); 
		for (int i = 11 ; i < 28 ; i+= 2) { // Large Tree Cover Playground from Above
			batch.draw(largetree, 
					worldStartX + i * Settings.SCALED_TILE_SIZE,
					worldStartY + 12 * Settings.SCALED_TILE_SIZE,
					Settings.SCALED_TILE_SIZE * 2, 
					Settings.SCALED_TILE_SIZE * 3); 
		}
		for (int i = 10 ; i > 6 ; i-= 2) { // Large Tree Cover Playground from Side
			batch.draw(largetree, 
					worldStartX + 27 * Settings.SCALED_TILE_SIZE,
					worldStartY + i * Settings.SCALED_TILE_SIZE,
					Settings.SCALED_TILE_SIZE * 2, 
					Settings.SCALED_TILE_SIZE * 3); 
		}
		batch.draw(tree, // decorating house from side
				worldStartX + 28 * Settings.SCALED_TILE_SIZE,
				worldStartY + 7 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 2);
		batch.draw(tree, // in the Playground
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 2);
		batch.draw(tree, // in the Playground
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 2);
		
		// -------------------- Put Sign ----------------------//
		
		batch.draw(sign, // Hotel Sign
				worldStartX + 11 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, //Width
				Settings.SCALED_TILE_SIZE * 1); //Height
		batch.draw(sign, // Playground sign
				worldStartX + 11 * Settings.SCALED_TILE_SIZE,
				worldStartY + 11 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1, //Width
				Settings.SCALED_TILE_SIZE * 1); //Height

		//----------------- Drawing Building (In front of Objects) --------------//
		batch.draw(storagedoor, // Side hotel tree
				worldStartX + 24 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				33, 
				49); 
		batch.draw(storage, // Side hotel tree
				worldStartX + 23 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 4, 
				Settings.SCALED_TILE_SIZE * 4); 
		batch.draw(house1, // House beside hotel
				worldStartX + 18 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 5,
				Settings.SCALED_TILE_SIZE * 4);
		
		batch.draw(house1, // House beside hotel
				worldStartX + 23 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 5,
				Settings.SCALED_TILE_SIZE * 4);
		batch.draw(hotel, // Hotel
				worldStartX + 12 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 5,
				Settings.SCALED_TILE_SIZE * 5);
		// --------------------------- Shops -----------------------------------//
		batch.draw(rug, // On the first shop
				worldStartX + 5 * Settings.SCALED_TILE_SIZE,
				worldStartY + 4 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 2,
				Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(shop1, // First shop
				worldStartX + 2 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 6,
				Settings.SCALED_TILE_SIZE * 4);
		
		batch.draw(rug, // On the second shop
				worldStartX + 5 * Settings.SCALED_TILE_SIZE,
				worldStartY + 9 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 2,
				Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(shop1, // Second shop (above first shop)
				worldStartX + 2 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 6,
				Settings.SCALED_TILE_SIZE * 4);
		
		batch.draw(rug, // On the third shop
				worldStartX + 5 * Settings.SCALED_TILE_SIZE,
				worldStartY + 14 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 2,
				Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(shop1, // Third shop (above second shop)
				worldStartX + 2 * Settings.SCALED_TILE_SIZE,
				worldStartY + 15 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 6,
				Settings.SCALED_TILE_SIZE * 4);
		batch.draw(menu1,  // for First shop
				worldStartX + 8 * Settings.SCALED_TILE_SIZE,
				worldStartY + 5 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(menu2, // for Second shop
				worldStartX + 8 * Settings.SCALED_TILE_SIZE,
				worldStartY + 10 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);
		
		batch.draw(menu3, // for Third shop
				worldStartX + 8 * Settings.SCALED_TILE_SIZE,
				worldStartY + 15 * Settings.SCALED_TILE_SIZE,
				Settings.SCALED_TILE_SIZE * 1,
				Settings.SCALED_TILE_SIZE * 1);

		
//====================================================================================================================
		playerX = worldStartX + player.getWorldX() * Settings.SCALED_TILE_SIZE;
		playerY = worldStartY + player.getWorldY() * Settings.SCALED_TILE_SIZE;
		
		dirX1 = worldStartX + 5 * Settings.SCALED_TILE_SIZE;
		dirY1 = worldStartY + 4 * Settings.SCALED_TILE_SIZE;
		
		dirY2 = worldStartY + 9 * Settings.SCALED_TILE_SIZE;
		
		dirY3 = worldStartY + 14 * Settings.SCALED_TILE_SIZE;
		
		floorX1 = worldStartX + 8 * Settings.SCALED_TILE_SIZE;
		floorY1 = worldStartY + 4 * Settings.SCALED_TILE_SIZE;
		
		floorY2 = worldStartY + 9 * Settings.SCALED_TILE_SIZE;
		
		floorY3 = worldStartY + 14 * Settings.SCALED_TILE_SIZE;
		
		if(playerX == dirX1 && playerY == dirY1 || playerX == (dirX1 + 32) && playerY == dirY1) { //shop 1
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
				money -= 100;
			}
			System.out.println("Noooooooooooooooooooooooooooooooooooooooooo");
		}
		
		if(playerX == dirX1 && playerY == dirY2 || playerX == (dirX1 + 32) && playerY == dirY2) { //shop 2
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
			}
			System.out.println("Yessssssssssssssssssssssssssssssssssssssss");
		}
		
		if(playerX == dirX1 && playerY == dirY3 || playerX == (dirX1 + 32) && playerY == dirY3) { //shop 3
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
			}
			System.out.println("Okkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk");
		}
		
		if(playerX == floorX1 && playerY == floorY1) {
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
				new Items_shop().item_info1();
			}
		}
		
		if(playerX == floorX1 && playerY == floorY2) {
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
				new Items_shop().item_info2();
			}
		}
		
		if(playerX == floorX1 && playerY == floorY3) {
			if(Gdx.input.isKeyJustPressed(Keys.I)) {
				new Items_shop().item_info3();
			}
		}
		
	//===============================================font===============================================================		
			font.draw(batch,
					"Money : " + money +"G",
					worldStartX + (player.getWorldX() - 1) * Settings.SCALED_TILE_SIZE,
					worldStartY + (player.getWorldY() + 2) * Settings.SCALED_TILE_SIZE );
	//===================================================================================================================
			
//		System.out.println(new Items_shop().getCost());
//		System.out.println(new Items_shop().getEnegy());
		
//		System.out.println("font_shopX : "+ dirX2);
//		System.out.println("font_shopX : "+ dirY2);
		
//		System.out.println("ShopX : " + (worldStartX + 2 * Settings.SCALED_TILE_SIZE));
//		System.out.println("ShopY : " + (worldStartY + 5 * Settings.SCALED_TILE_SIZE));
		
//		System.out.println("PlayerX : " + playerX);
//		System.out.println("PlayerY : " + playerY);
		batch.end();
		
	}

	@Override
	public void resize(int width, int height) {
	}

	@Override
	public void pause() {
	}

	@Override
	public void resume() {
	}

	@Override
	public void hide() {
	}

	@Override
	public void dispose() {
	}
	
}