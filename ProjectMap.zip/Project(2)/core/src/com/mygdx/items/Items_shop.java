package com.mygdx.items;
import javax.swing.*;
import java.net.URL;
import java.awt.*;
import java.awt.event.*;


public class Items_shop implements ActionListener{
	 private JFrame fr;
	 private JPanel p1, p2, p3;
	 private JButton btn1, btn2;
	 private JLabel la1;
	 private Icon icon;
	 private int cost,enegy;

	 
	 public void item_info1(){
		 fr = new JFrame("Items");
	     p1 = new JPanel();
	     p2 = new JPanel();
	     btn1 = new JButton("Cancel");
	     ImageIcon icon = null;
	     
	     btn1.addActionListener(this);
	     
	     fr.setLayout(new GridLayout(2, 1));
	     p1.setLayout(new BorderLayout());
	     p2.setLayout(new FlowLayout());
	     
	     URL imageURL = Items_shop.class.getResource("food_01.png");
	     if (imageURL != null) {
	     icon = new ImageIcon(imageURL);
	     }
	     
	     la1 = new JLabel("Cost: 100G      Enegy: 200",icon, JLabel.CENTER);
	     la1.setVerticalTextPosition(JLabel.BOTTOM);
	     la1.setHorizontalTextPosition(JLabel.CENTER);

	     
	     p1.add(la1);
	     
	     p2.add(btn1);
	     
	     fr.add(p1);
	     fr.add(p2);
	     
	     fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	     fr.setSize(300, 215);
	     fr.setVisible(true);
	 }
	 
	 public void item_info2(){
		 fr = new JFrame("Items");
	     p1 = new JPanel();
	     p2 = new JPanel();
	     btn1 = new JButton("Cancel");
	     ImageIcon icon = null;
	     
	     btn1.addActionListener(this);
	     
	     fr.setLayout(new GridLayout(2, 1));
	     p1.setLayout(new BorderLayout());
	     p2.setLayout(new FlowLayout());
	     
	     URL imageURL = Items_shop.class.getResource("food_11.png");
	     if (imageURL != null) {
	     icon = new ImageIcon(imageURL);
	     }
	     
	     la1 = new JLabel("Cost: 100G      Enegy: 200",icon, JLabel.CENTER);
	     la1.setVerticalTextPosition(JLabel.BOTTOM);
	     la1.setHorizontalTextPosition(JLabel.CENTER);

	     
	     p1.add(la1);
	     
	     p2.add(btn1);
	     
	     fr.add(p1);
	     fr.add(p2);
	     
	     fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	     fr.setSize(300, 215);
	     fr.setVisible(true);
	 }
	 
	 public void item_info3(){
		 fr = new JFrame("Items");
	     p1 = new JPanel();
	     p2 = new JPanel();
	     btn1 = new JButton("Cancel");
	     ImageIcon icon = null;
	     
	     btn1.addActionListener(this);
	     
	     fr.setLayout(new GridLayout(2, 1));
	     p1.setLayout(new BorderLayout());
	     p2.setLayout(new FlowLayout());
	     
	     URL imageURL = Items_shop.class.getResource("food_13.png");
	     if (imageURL != null) {
	     icon = new ImageIcon(imageURL);
	     }
	     
	     la1 = new JLabel("Cost: 100G      Enegy: 200",icon, JLabel.CENTER);
	     la1.setVerticalTextPosition(JLabel.BOTTOM);
	     la1.setHorizontalTextPosition(JLabel.CENTER);

	     
	     p1.add(la1);
	     
	     p2.add(btn1);
	     
	     fr.add(p1);
	     fr.add(p2);
	     
	     fr.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	     fr.setSize(300, 215);
	     fr.setVisible(true);
	 }

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource().equals(btn1)) {
			 fr.dispose();
		}
		
	}
}
