package com.mygdx.model;

public enum TERRAIN {
	GRASS_1,
	GRASS_2,
	;
}